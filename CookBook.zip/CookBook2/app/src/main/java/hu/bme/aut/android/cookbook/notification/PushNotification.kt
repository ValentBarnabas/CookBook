package hu.bme.aut.android.cookbook.notification

data class PushNotification (
    val data: NotificationData,
    val to: String
)