package hu.bme.aut.android.cookbook.notification

data class NotificationData(
    val title: String,
    val message: String
)