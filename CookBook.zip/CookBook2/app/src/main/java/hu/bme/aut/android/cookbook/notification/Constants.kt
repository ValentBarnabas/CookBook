package hu.bme.aut.android.cookbook.notification

class Constants {

    companion object {
        const val BASE_URL = "https://fcm.googleapis.com"
        const val SERVER_KEY = "AAAAtOJh-3I:APA91bGJIdcymf3JWIjjxiynaV_aj2OeIBBL5FYndbPcgAQIb0l7Nu0bjrA6hG_0YmqHEe6wjPFS9jfr2smErGr9HnmrIUjvK1YSAwmssDmvxwb9CFpjXGqvakcZVEUGy5mtbuns9oXt"
        const val CONTENT_TYPE = "application/json"
    }
}